module.exports = function(app, opts) {
  var service = {name: 'mockPlugin'};
  return service;
};